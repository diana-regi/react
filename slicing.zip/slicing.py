# String slicing
String = 'BEAUTIFUL'

s1 = slice(3)
s2 = slice(1, 5, 2)

print("String slicing")
print(String[s1])
print(String[s2])
